/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_ANALYSIS_API_URL?: string;
}
